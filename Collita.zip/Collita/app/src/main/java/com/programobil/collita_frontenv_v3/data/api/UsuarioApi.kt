/* Aplicacion Collita v1
 Participantes: Godos García Jesús Emmanuel 217o02950,
                Ortiz Sánchez Néstor Éibar 217o03062,
                Axel David Ruiz Vargas 217o03139,
                Ramiro Aguilar Morales 207o02190*/
package com.programobil.collita_frontenv_v3.data.api

import retrofit2.http.DELETE
import retrofit2.http.Path

interface UsuarioApi {
    @DELETE("usuarios/{id}")
    suspend fun deleteUsuario(@Path("id") id: String): Unit? {
        return null
    }
} 